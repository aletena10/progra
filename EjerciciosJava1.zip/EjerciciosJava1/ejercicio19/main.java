public class main {
    public static void main(String[] args) {
        int a = 10, b = 5;
        int c = 7, d = 0;

        System.out.println("Suma de " + a + " y " + b + " = " + OperacionesBasicas.sumar(a, b));
        System.out.println("Resta de " + a + " y " + b + " = " + OperacionesBasicas.restar(a, b));
        System.out.println("Multiplicación de " + a + " y " + b + " = " + OperacionesBasicas.multiplicar(a, b));
        System.out.println("División de " + a + " y " + b + " = " + OperacionesBasicas.dividir(a, b));

        // Prueba con división por 0
        System.out.println("División de " + c + " y " + d + " = " + OperacionesBasicas.dividir(c, d));
    }
}
