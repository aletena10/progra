public class main {
    public static void main(String[] args) {
        // Crear una instancia de Comparador
        Comparador comparador = new Comparador();

        // Definir valores para comparar
        int num1 = 8;
        int num2 = 5;

        // Llamar al método compararNumeros()
        comparador.compararNumeros(num1, num2);
    }
}
