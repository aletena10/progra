public class Comparador {
    // Método para comparar dos números
    public void compararNumeros(int a, int b) {
        if (a > b) {
            System.out.println(a + " es mayor que " + b);
        } else if (a < b) {
            System.out.println(a + " es menor que " + b);
        } else {
            System.out.println(a + " es igual a " + b);
        }
    }
}
