import operaciones.Multiplicador;

public class main {
    public static void main(String[] args) {
        Multiplicador multi = new Multiplicador();
        int resultado = multi.multiplicar(5, 3);
        System.out.println("El resultado de la multiplicación es: " + resultado);
    }
}
