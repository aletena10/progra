public class saludo {
    // Variable de instancia
    String mensaje = "Hola, bienvenido a Java";

    // Método para mostrar el mensaje
    public void mostrarMensaje() {
        System.out.println(mensaje);
    }
}
