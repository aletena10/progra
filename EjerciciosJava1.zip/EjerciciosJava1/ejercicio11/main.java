public class main {
    public static void main(String[] args) {
        // Crear una instancia de la clase Saludo
        saludo saludo = new saludo();

        // Llamar al método mostrarMensaje()
        saludo.mostrarMensaje();
    }
}
