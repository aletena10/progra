public class main {
    public static void main(String[] args) {
        Circunferencia circ = new Circunferencia();

        // Radios de ejemplo
        double[] radios = {1.5, 3.0, 5.2, 7.8};

        for (double radio : radios) {
            double resultado = circ.calcularCircunferencia(radio);
            System.out.println("La circunferencia de un círculo con radio " + radio + " es: " + resultado);
        }
    }
}
