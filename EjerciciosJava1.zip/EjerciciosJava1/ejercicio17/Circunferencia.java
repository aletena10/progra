public class Circunferencia {
    // Definir la constante PI
    public static final double PI = 3.1416;

    // Método para calcular la circunferencia
    public double calcularCircunferencia(double radio) {
        return 2 * PI * radio;
    }
}
