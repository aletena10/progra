public class main {  // El nombre de la clase debe coincidir con el nombre del archivo
    public static void main(String[] args) {
        Proceso proceso = new Proceso();
        proceso.pasoDos();
    }
}
