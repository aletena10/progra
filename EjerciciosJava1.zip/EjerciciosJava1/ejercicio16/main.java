public class main{
    public static void main(String[] args) {
        Verificador verificador = new Verificador();
        
        // Probar con diferentes valores
        int[] numeros = {5, 10, 12, 15, 20, 7, 22};

        for (int num : numeros) {
            System.out.println("¿El número " + num + " es mayor que 10 y par? " + verificador.esMayorYPar(num));
        }
    }
}
