public class Verificador {
    public boolean esMayorYPar(int numero) {
        return numero > 10 && numero % 2 == 0;
    }
}
