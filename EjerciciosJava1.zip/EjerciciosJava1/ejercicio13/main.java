public class main {
    public static void main(String[] args) {
        // Crear una instancia de AreaCuadrado
        AreaCuadrado areaCuadrado = new AreaCuadrado();

        // Definir el valor del lado
        int lado = 5;

        // Calcular el área y almacenar el resultado
        int area = areaCuadrado.calcularArea(lado);

        // Mostrar el resultado en la consola
        System.out.println("El área del cuadrado con lado " + lado + " es: " + area);
    }
}
