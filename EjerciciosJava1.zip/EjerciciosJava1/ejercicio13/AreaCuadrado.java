public class AreaCuadrado {
    // Método para calcular el área de un cuadrado
    public int calcularArea(int lado) {
        return lado * lado;
    }
}
