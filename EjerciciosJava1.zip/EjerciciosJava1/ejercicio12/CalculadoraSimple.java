public class CalculadoraSimple {
    // Variables de instancia
    int num1 = 10;
    int num2 = 5;
    int resultado;

    // Método para realizar las operaciones y mostrar los resultados
    public void realizarOperaciones() {
        resultado = num1 + num2;
        System.out.println("Suma: " + num1 + " + " + num2 + " = " + resultado);

        resultado = num1 - num2;
        System.out.println("Resta: " + num1 + " - " + num2 + " = " + resultado);

        resultado = num1 * num2;
        System.out.println("Multiplicación: " + num1 + " * " + num2 + " = " + resultado);

        if (num2 != 0) {
            resultado = num1 / num2;
            System.out.println("División: " + num1 + " / " + num2 + " = " + resultado);
        } else {
            System.out.println("División: No es posible dividir entre 0.");
        }
    }

    // Método main para ejecutar el programa
    public static void main(String[] args) {
        // Crear una instancia de la calculadora
        CalculadoraSimple calculadora = new CalculadoraSimple();
        
        // Llamar al método para realizar las operaciones
        calculadora.realizarOperaciones();
    }
}
