public class Conversor {
    // Método para convertir double a int usando casting
    public int convertirDoubleAInt(double numero) {
        return (int) numero;
    }
}
