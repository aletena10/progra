public class OperacionesBasicas {
    // Método estático para sumar
    public static int sumar(int a, int b) {
        return a + b;
    }

    // Método estático para restar
    public static int restar(int a, int b) {
        return a - b;
    }

    // Método estático para multiplicar
    public static int multiplicar(int a, int b) {
        return a * b;
    }

    // Método estático para dividir (manejo de división por cero)
    public static double dividir(int a, int b) {
        if (b == 0) {
            System.out.println("Error: No se puede dividir por cero.");
            return Double.NaN; // Devuelve "No es un número" en caso de división por 0
        }
        return (double) a / b;
    }
}
