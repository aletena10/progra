public class main{
    public static void main(String[] args) {
        Conversor conversor = new Conversor();

        // Números decimales de ejemplo
        double[] numeros = {5.8, 10.2, 3.99, 7.5, -4.7};

        for (double num : numeros) {
            int resultado = conversor.convertirDoubleAInt(num);
            System.out.println("El número " + num + " convertido a entero es: " + resultado);
        }
    }
}
